

void inicializar_tabela_zerada(unsigned int tab[]);

void preencher_tabela(FILE *arquivo, unsigned int tab[]);

