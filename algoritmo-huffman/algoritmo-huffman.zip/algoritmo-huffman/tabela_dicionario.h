

char** alocar_tabela(int colunas);

void preencher_dicionario(char** dicionario, NO* raiz, char *codigo, int colunas);

void liberar_tabela_dicionario(char **dicionario);

//void imprimir_tabela_dicionario(char** dicionario);